package com.cc.iosconnect;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * SystemUI (com.android.systemui) me chalta hai.
 * Control Center asal me plugin APK (MIUISystemUIPlugin) ke apne ClassLoader me hota hai,
 * isliye pehle PluginInstance$Factory.getClassLoader hook karke plugin ka loader pakadte hain.
 * Target: miui.systemui.controlcenter.panel.main.media.MediaPlayerPanel (ConstraintLayout)
 */
public class MainHook implements IXposedHookLoadPackage {
    static final String TAG = "IOSConnect";
    static final String PANEL = "miui.systemui.controlcenter.panel.main.media.MediaPlayerPanel";
    static final int KEY_DONE = 0x7e0a0001;   // panel par "install ho chuka" marker
    static final int KEY_HIDE = 0x7e0a0002;   // original children par "hamesha GONE" marker

    private final Set<Class<?>> hooked = Collections.synchronizedSet(
            Collections.newSetFromMap(new WeakHashMap<Class<?>, Boolean>()));
    private volatile boolean visHooked = false;

    @Override
    public void handleLoadPackage(final LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;

        tryClassLoader(lp.classLoader);

        // 1) Plugin ClassLoader pakadna
        try {
            Class<?> f = XposedHelpers.findClass(
                    "com.android.systemui.shared.plugins.PluginInstance$Factory", lp.classLoader);
            XposedBridge.hookAllMethods(f, "getClassLoader", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof ClassLoader) tryClassLoader((ClassLoader) r);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": PluginInstance hook fail: " + t);
        }

        // 2) Fallback: agar upar wala miss ho jaye to class load hote hi pakad lo
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (PANEL.equals(p.args[0]) && p.getResult() instanceof Class) {
                                hookPanel((Class<?>) p.getResult());
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": loadClass fallback fail: " + t);
        }
    }

    private void tryClassLoader(ClassLoader cl) {
        try {
            hookPanel(Class.forName(PANEL, false, cl));
        } catch (Throwable ignored) { /* is loader me nahi hai */ }
    }

    private void hookPanel(Class<?> c) {
        if (!hooked.add(c)) return;
        XposedBridge.log(TAG + ": MediaPlayerPanel mil gaya, hook laga raha hun");
        ensureVisibilityHook();
        XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                final ViewGroup panel = (ViewGroup) p.thisObject;
                panel.post(new Runnable() {
                    @Override public void run() { install(panel); }
                });
            }
        });
    }

    /** Original media card ke children ko dobara visible hone se rokna. */
    private synchronized void ensureVisibilityHook() {
        if (visHooked) return;
        visHooked = true;
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                View v = (View) p.thisObject;
                if (v.getTag(KEY_HIDE) != null) p.args[0] = View.GONE;
            }
        });
    }


    private void install(ViewGroup panel) {
        try {
            if (panel.getTag(KEY_DONE) != null) return;
            panel.setTag(KEY_DONE, Boolean.TRUE);

            for (int i = 0; i < panel.getChildCount(); i++) {
                View ch = panel.getChildAt(i);
                ch.setTag(KEY_HIDE, Boolean.TRUE);
                ch.setVisibility(View.GONE);
            }

            float d = panel.getResources().getDisplayMetrics().density;
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0x55808A99);
            bg.setCornerRadius(28 * d);
            bg.setStroke(Math.max(1, (int) d), 0x66FFFFFF);
            panel.setBackground(bg);

            ClusterView cv = new ClusterView(panel.getContext());
            ViewGroup.LayoutParams lp;
            try {
                // ConstraintLayout ke liye parent ke 4 kono se bandh do
                lp = (ViewGroup.LayoutParams) XposedHelpers.callMethod(panel, "generateDefaultLayoutParams");
                lp.width = 0;
                lp.height = 0;
                XposedHelpers.setIntField(lp, "leftToLeft", 0);
                XposedHelpers.setIntField(lp, "rightToRight", 0);
                XposedHelpers.setIntField(lp, "topToTop", 0);
                XposedHelpers.setIntField(lp, "bottomToBottom", 0);
            } catch (Throwable t) {
                lp = new ViewGroup.LayoutParams(-1, -1);
            }
            panel.addView(cv, lp);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": install fail: " + t);
        }
    }
}
