package com.cc.iosconnect;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XposedBridge;

/**
 * Neeche ke stock grid se duplicate tiles (Wi-Fi, Data, Bluetooth, Hotspot, Torch, Mute) chhupata hai.
 * Tile ko uske contentDescription / view-id / class naam / andar ki tile-spec se pehchanta hai.
 * Kaunse tiles chhupane hain: neeche EXACT aur PART list (ek hi jagah).
 */
final class DupHider implements ViewTreeObserver.OnGlobalLayoutListener, Runnable {
    // poora naam / spec bilkul yehi ho
    private static final String[] EXACT = {
            "wifi", "wi-fi", "cell", "data", "mobiledata", "bt", "bluetooth",
            "hotspot", "flashlight", "torch", "mute", "silent"};
    // naam me ye lafz aaye
    private static final String[] PART = {
            "wi-fi", "wifi", "wlan", "mobile data", "mobile network", "cellular",
            "bluetooth", "hotspot", "tether", "flashlight", "torch", "mute", "silent"};
    private static final String[] GETTERS = {"getTileSpec", "getSpec", "getTileKey", "getKey"};

    private final ClusterView cluster;
    private final Map<View, String> seen = new WeakHashMap<>();
    private boolean pending;
    private int logged;

    DupHider(ClusterView c) { cluster = c; }

    @Override public void onGlobalLayout() {
        if (pending) return;
        pending = true;
        cluster.postDelayed(this, 300);
    }

    @Override public void run() {
        pending = false;
        try {
            if (!cluster.isAttachedToWindow()) return;
            int[] loc = new int[2];
            cluster.getLocationOnScreen(loc);
            scan(cluster.getRootView(), loc[1]);
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: DupHider scan fail: " + t);
        }
    }

    private int dp(float v) {
        return Math.round(v * cluster.getResources().getDisplayMetrics().density);
    }

    private void scan(View v, int cTop) {
        if (v == cluster || v.getTag(MainHook.KEY_HIDE) != null) return;
        if (v.getVisibility() == View.GONE) return;
        if (examine(v, cTop)) return;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) scan(g.getChildAt(i), cTop);
        }
    }

    private boolean examine(View v, int cTop) {
        int w = v.getWidth(), h = v.getHeight();
        CharSequence cd = v.getContentDescription();
        String sig = (cd == null ? "" : cd.toString()) + "|" + w + "x" + h;
        if (sig.equals(seen.get(v))) return false;
        seen.put(v, sig);

        boolean tileSized = w >= dp(40) && h >= dp(40) && w <= dp(130) && h <= dp(130);
        List<String> keys = new ArrayList<>();
        if (cd != null) keys.add(cd.toString());
        if (v.getId() != View.NO_ID) {
            try { keys.add(v.getResources().getResourceEntryName(v.getId())); } catch (Throwable ignored) { }
        }
        if (v.getTag() instanceof String) keys.add((String) v.getTag());
        keys.add(v.getClass().getSimpleName());
        if (tileSized) reflectKeys(v, keys);

        String hit = null;
        for (String k : keys) {
            hit = match(k);
            if (hit != null) break;
        }
        if (hit == null) {
            if (tileSized && logged < 40) {
                logged++;
                XposedBridge.log("IOSConnect: cand " + v.getClass().getName() + " " + w + "x" + h + " keys=" + keys);
            }
            return false;
        }
        return hide(v, hit, cTop);
    }

    private boolean hide(View m, String why, int cTop) {
        View t = m;
        int min = dp(40);
        while ((t.getWidth() < min || t.getHeight() < min) && t.getParent() instanceof ViewGroup) {
            t = (View) t.getParent();
        }
        int w = t.getWidth(), h = t.getHeight();
        if (w < min || h < min || w > dp(130) || h > dp(130)) return false;
        float ar = (float) w / h;
        if (ar < 0.6f || ar > 1.6f) return false;
        if (t == cluster || containsCluster(t)) return false;
        int[] l = new int[2];
        t.getLocationOnScreen(l);
        if (l[1] < cTop - dp(4)) return false;          // upar wale header icons ko na chhuo
        t.setTag(MainHook.KEY_HIDE, Boolean.TRUE);
        t.setVisibility(View.GONE);
        XposedBridge.log("IOSConnect: duplicate hide '" + why + "' " + t.getClass().getName() + " " + w + "x" + h);
        return true;
    }

    private boolean containsCluster(View t) {
        View p = cluster;
        while (p != null) {
            if (p == t) return true;
            p = (p.getParent() instanceof View) ? (View) p.getParent() : null;
        }
        return false;
    }

    private static String match(String k) {
        if (k == null || k.length() > 64) return null;
        String s = k.toLowerCase();
        if (s.contains("saver") || s.contains("setting")) return null;
        for (String e : EXACT) if (s.equals(e)) return e;
        for (String p : PART) if (s.contains(p)) return p;
        return null;
    }

    private void reflectKeys(View v, List<String> keys) {
        int n = 0;
        for (Class<?> k = v.getClass();
             k != null && k != Object.class && !k.getName().startsWith("android.");
             k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                if (++n > 60) return;
                if (Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    Object o = f.get(v);
                    if (o == null || o instanceof View || o instanceof Context) continue;
                    if (o instanceof CharSequence) { keys.add(o.toString()); continue; }
                    String tn = o.getClass().getName();
                    if (tn.startsWith("java.") || tn.startsWith("android.")) continue;
                    String s = specOf(o);
                    if (s != null) keys.add(s);
                } catch (Throwable ignored) { }
            }
        }
    }

    private static String specOf(Object o) {
        for (String g : GETTERS) {
            try {
                Method m = o.getClass().getMethod(g);
                Object r = m.invoke(o);
                if (r instanceof CharSequence) return r.toString();
            } catch (Throwable ignored) { }
        }
        return null;
    }
}
