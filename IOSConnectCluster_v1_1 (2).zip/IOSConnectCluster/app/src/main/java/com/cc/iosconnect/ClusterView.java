package com.cc.iosconnect;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

/** 2x2 grid: Data, Wi-Fi, Hotspot, Bluetooth (fixed, edit mode nahi). Stock duplicates DupHider chhupata hai. */
public class ClusterView extends ViewGroup {
    private static final int[] KINDS = {TileView.DATA, TileView.WIFI, TileView.HOTSPOT, TileView.BT};
    private final TileView[] tiles = new TileView[KINDS.length];
    private DupHider hider;
    private ViewTreeObserver obs;

    public ClusterView(Context c) {
        super(c);
        setClipChildren(false);
        for (int i = 0; i < KINDS.length; i++) {
            tiles[i] = new TileView(c, KINDS[i]);
            addView(tiles[i]);
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        hider = new DupHider(this);
        obs = getViewTreeObserver();
        obs.addOnGlobalLayoutListener(hider);
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (hider != null) {
            removeCallbacks(hider);
            if (obs != null && obs.isAlive()) obs.removeOnGlobalLayoutListener(hider);
        }
        hider = null;
        obs = null;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        int pad = dp(14), gap = dp(10);
        int cell = Math.max(0, Math.min((w - 2 * pad - gap) / 2, (h - 2 * pad - gap) / 2));
        int spec = MeasureSpec.makeMeasureSpec(cell, MeasureSpec.EXACTLY);
        for (View t : tiles) t.measure(spec, spec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l, h = b - t;
        int gap = dp(10);
        int cell = tiles[0].getMeasuredWidth();
        int sx = (w - (2 * cell + gap)) / 2;
        int sy = (h - (2 * cell + gap)) / 2;
        for (int i = 0; i < tiles.length; i++) {
            int x = sx + (i % 2) * (cell + gap);
            int y = sy + (i / 2) * (cell + gap);
            tiles[i].layout(x, y, x + cell, y + cell);
        }
    }
}
