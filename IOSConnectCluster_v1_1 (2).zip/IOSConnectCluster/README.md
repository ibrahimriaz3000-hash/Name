# iOS Connect Cluster (LSPosed)
SystemUI me Control Center ki "No playback" media card ki jaga 2x2 cluster: Data, Wi-Fi, Hotspot, Bluetooth.

## Build (GitHub se)
1. Is folder ko naye GitHub repo me push karo (.github/workflows/build.yml saath jaye).
2. Actions tab -> "Build APK" -> artifact `IOSConnectCluster-apk` download.
3. APK install -> LSPosed me enable, scope: System UI -> SystemUI restart (ya reboot).
Xposed API ab local stub module (`xposed-stub`) se aati hai, koi external download nahi.

## Debug
LSPosed logs me "IOSConnect:" dhundo. "MediaPlayerPanel mil gaya" aaye to hook lag gaya.

## v1.2
- Cluster ab fixed hai: Data, Wi-Fi, Hotspot, Bluetooth. Edit mode / picker / long-press edit hata diya.
- Neeche ke stock grid se duplicate tiles (Wi-Fi, Data, Bluetooth, Hotspot, Torch, Mute) `DupHider.java` chhupata hai.
  Kaunse chhupane hain: `DupHider.java` ke upar EXACT / PART list.
- Agar koi duplicate na hate to LSPosed logs me `IOSConnect: cand` lines dekho (tile ka asal naam wahan likha hota hai).
